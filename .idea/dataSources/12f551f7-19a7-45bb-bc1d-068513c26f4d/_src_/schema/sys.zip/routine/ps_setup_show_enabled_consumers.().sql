CREATE PROCEDURE sys.ps_setup_show_enabled_consumers()
  BEGIN SELECT name AS enabled_consumers FROM performance_schema.setup_consumers WHERE enabled = 'YES' ORDER BY enabled_consumers; END;
