CREATE FUNCTION sys.quote_identifier(in_identifier TEXT)
  RETURNS TEXT
  BEGIN RETURN CONCAT('`', REPLACE(in_identifier, '`', '``'), '`'); END;
